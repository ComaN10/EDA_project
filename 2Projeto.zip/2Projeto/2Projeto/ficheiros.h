#pragma once
#ifndef FUNCOESFICHEIROS_H
#define FUNCOESFICHEIROS_H

using namespace std;

int LinhasFicheiro(string Ficheiro);

#endif

