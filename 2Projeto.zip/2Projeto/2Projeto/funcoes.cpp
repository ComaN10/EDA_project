#include "funcoes.h"

using namespace std;

//*************************************** Fun��es Horta ***************************************

void criaHorta(horta& h,char letra, string responsavel, int capacidade, string area, int nHortas) {
	h.nHortas = nHortas;
	horta::hortas* novo = new horta::hortas();
	novo->letra = letra;
	novo->responsavel = responsavel;
	novo->capacidade = capacidade;
	novo->area = area;
	novo->ocupacao = 0;
	novo->produtosColhidos = 0;
	novo->produtos = NULL;
	novo->colhidos = NULL;
	novo->seguinte = NULL;
	if (h.inicio == NULL) {
		h.inicio = novo;
	}
	else {
		horta::hortas* iterator = h.inicio;
		while(iterator->seguinte != 0){
			iterator = iterator->seguinte;
		}
		iterator->seguinte = novo;
	}
}

void imprimeHortas(horta& h) {
	horta::hortas* iterator = h.inicio;
	while(iterator != 0){
		cout << "Horta: " << iterator->letra << "  ||  " << "Respons�vel: " << iterator->responsavel << "  ||  " << "Capacidade: " << iterator->capacidade << "  ||  " << "Ocupa��o: " << iterator->ocupacao << "  ||  " << "�rea: " << iterator->area << endl;
		cout << "---------------------------------------------------------------------------" << endl;
		produto* iteratorP = iterator->produtos;
		while (iteratorP != 0) {
			cout << "Produto: " << iteratorP->nomeProduto << "  ||  " << "Fornecedor: " << iteratorP->fornecedor << "  ||  " << "�rea: " << iteratorP->area << "  ||  " << "Rega: " << iteratorP->rega << endl;
			iteratorP = iteratorP->seguinte;
		}
		cout << "-------------------------------------------------------------------------------------------------------" << endl;
		cout << "-------------------------------------------------------------------------------------------------------" << endl;
		iterator = iterator->seguinte;
	}
	cout << endl;
}

//*************************************** Fun��es Armazem ***************************************

void insereProduto(int quantidade, string nome[100], int tamanho_N, string fornecedores[50], int tamanho_F, RArea* area, armazem& a) {
	for (int j = 0; j < quantidade; j++) {
		int N = rand() % tamanho_N + 0;
		int F = rand() % tamanho_F + 0;
		int A = rand() % area->tam + 0;
		int rega = rand() % 5+1;
		
		criaProduto(a, nome[N], fornecedores[F], area->area[A], rega);
	}
}

void criaProduto(armazem& a, string nome, string fornecedor, string area, int rega) {
	produto* novo = new produto();
	novo->nomeProduto = nome;
	novo->fornecedor = fornecedor;
	novo->area = area;
	novo->rega = rega;
	novo->seguinte = NULL;
	if (a.inicio == NULL) {
		a.inicio = novo;
		a.quantidade++;
	}
	else {
		produto* iterator = a.inicio;
		while (iterator->seguinte != 0) {
			iterator = iterator->seguinte;
		}
		iterator->seguinte = novo;
		a.quantidade++;
	}
}


void imprimeArmazem(armazem& a) {
	produto* iterator = a.inicio;
	cout << "O armaz�m cont�m: " << a.quantidade << " produtos" << endl;
	while (iterator != 0) {
		cout << "Produto: " << iterator->nomeProduto << "  ||  " << "Fornecedor: " << iterator->fornecedor << "  ||  " << "�rea: " << iterator->area << "  ||  " << "Rega: " << iterator->rega << endl;
		iterator = iterator->seguinte;
	}
	cout << endl;
}

//*************************************** Menu op��o "s" ***************************************

void colheProdutos(horta& h) {

	horta::hortas* iterator = h.inicio;

	cout << "Produtos colhidos:" << endl;
	while (iterator != 0) {
		produto* iteratorP = iterator->produtos;
		bool segundoP = false;
		while (iteratorP != 0 && segundoP == false) {
			int probalidade = rand() % 101;
			if (probalidade < 26) {
				if (iteratorP->seguinte == 0) {
					produto* temp = iteratorP;
					iteratorP = NULL;
					temp->seguinte = NULL;
					iterator->produtos = iteratorP;
					insereProdutoColhido(temp, h, iterator);
					imprimeProdutoColhido(temp, iterator);
					iterator->produtosColhidos++;
					iterator->ocupacao--;
				}
				else {
					produto* temp = iteratorP;
					iteratorP = temp->seguinte;
					temp->seguinte = NULL;
					iterator->produtos = iteratorP;
					insereProdutoColhido(temp, h, iterator);
					imprimeProdutoColhido(temp, iterator);
					iterator->produtosColhidos++;
					iterator->ocupacao--;
				}
			}
			else {
				segundoP = true;
			}
		}
		iteratorP = iterator->produtos;
		while (segundoP == true && iteratorP->seguinte != 0) {
			int probalidade = rand() % 101;
			if (probalidade < 26) {
				if (iteratorP->seguinte->seguinte == 0) {
					produto* temp = iteratorP->seguinte;
					iteratorP->seguinte = NULL;
					temp->seguinte = NULL;
					insereProdutoColhido(temp, h, iterator);
					imprimeProdutoColhido(temp, iterator);
					iterator->produtosColhidos++;
					iterator->ocupacao--;
				}
				else {
					produto* temp = iteratorP->seguinte;
					iteratorP->seguinte = temp->seguinte;
					temp->seguinte = NULL;
					insereProdutoColhido(temp, h, iterator);
					imprimeProdutoColhido(temp, iterator);
					iterator->produtosColhidos++;
					iterator->ocupacao--;
				}
			}
			if (iteratorP->seguinte != 0) {
				iteratorP = iteratorP->seguinte;
			}
			else {
				segundoP = false;
			}
		}
		iterator = iterator->seguinte;
	}
	cout << endl << endl;
}

void insereProdutoColhido(produto* temp, horta& h, horta::hortas* iterator) {
	horta::hortas* iteratorS = h.inicio;
	iteratorS = iterator;
	colhido* iteratorV = iteratorS->colhidos;
	bool colocado = false;
	colhido* novo = new colhido();
	novo->nome = temp->nomeProduto;
	novo->rega = temp->rega;
	novo->dir = NULL;
	novo->esq = NULL;
	while (colocado == false) {
		if (iteratorV == 0) {
			iteratorV = novo;
			colocado = true;
			iteratorS->colhidos = iteratorV;
		}
		else if (iteratorV->rega < temp->rega) {
			if (iteratorV->dir == NULL) {
				iteratorV->dir = novo;
				colocado = true;
			}
			else {
				iteratorV = iteratorV->dir;
			}
		}
		else if (iteratorV->rega >= temp->rega) {
			if (iteratorV->esq == NULL) {
				iteratorV->esq = novo;
				colocado = true;
			}
			else {
				iteratorV = iteratorV->esq;
			}
		}
	}

}

void imprimeProdutoColhido(produto* temp, horta::hortas* iterator) {
	cout << "O produto " << temp->nomeProduto << " foi colhido com o tempo de rega " << temp->rega << "." << endl;
}

void atualiza(armazem& a, horta& h) {
	int quantidade = 0;
	bool prioridade = false;
	produto* iterator = a.inicio;


	while (quantidade < 10 && iterator->seguinte != 0) {
		bool produtoInserido = false;
		if (prioridade == false) {
			horta::hortas* iteratorS = h.inicio;
			while (iteratorS != 0 && produtoInserido == false) {
				if (iteratorS->area == iterator->area) {
					if (iteratorS->ocupacao < iteratorS->capacidade) {
						produto* temp = iterator;
						iterator = temp->seguinte;
						temp->seguinte = NULL;
						a.inicio = iterator;
						quantidade++;
						insereProdutoHorta(temp, h);
						a.quantidade--;
						produtoInserido = true;
					}
				}
				iteratorS = iteratorS->seguinte;
			}
		}
		if (produtoInserido == false) {
			prioridade = true;
		}
		if (prioridade == true) {
			horta::hortas* iteratorS = h.inicio;
			produto* temp = iterator->seguinte;
			while (iteratorS != 0 && produtoInserido == false) {
				if (iteratorS->area == temp->area) {
					if (iteratorS->ocupacao < iteratorS->capacidade) {
						iterator->seguinte = temp->seguinte;
						temp->seguinte = NULL;
						quantidade++;
						insereProdutoHorta(temp, h);
						a.quantidade--;
						produtoInserido = true;
					}
				}
				iteratorS = iteratorS->seguinte;
			}
		}
		if (produtoInserido == false) {
			iterator = iterator->seguinte;
		}
	}

	imprimeHortas(h);
}

void insereProdutoHorta(produto* temp, horta& h) {
	horta::hortas* iterator = h.inicio;
	bool produtoInserido = false;
	while (iterator != 0 && produtoInserido == false) {
		if (iterator->area == temp->area) {
			if (iterator->ocupacao < iterator->capacidade) {
				temp->seguinte = iterator->produtos;
				iterator->produtos = temp;
				iterator->ocupacao++;
				produtoInserido = true;
			}
		}
		iterator = iterator->seguinte;
	}

}

//*************************************** Menu op��o "g" ***************************************
//******************** Gestor ********************

void menu(armazem& a, horta& h, RArea* areas) {
	bool sair = false;
	char opcao;
	do
	{
		cout << "\nEscolha uma op��o:\n";
		cout << "1 - colher Produto" << endl;
		cout << "2 - Atualizar Tempo de Rega" << endl;
		cout << "3 - Gravar Horta" << endl;
		cout << "4 - Carregar horta" << endl;
		cout << "5 - Imprimir Produtos" << endl;
		cout << "6 - Criar nova �rea" << endl;
		cout << "7 - Mostrar Registo dos Produtos Colhidos" << endl;
		cout << "8 - Alterar area na horta" << endl;
		cout << "0 - voltar" << endl;
		cin >> opcao;
		cout << endl;
		switch (opcao) {
		case '1':
			cout << "Escolheu a op��o Remover Produto" << endl;
			removerProduto(a, h);
			break;
		case '2':
			cout << "Escolheu a op��o Atualizar Rega" << endl;
			atualizaRega(a,h);
			break;
		case '3':
			cout << "Escolheu a op��o Guardar Horta" << endl;
			gravaHorta("hortas.txt", "armazem.txt", "registo.txt", h, a);
			break;
		case '4':
			cout << "Escolheu a op��o Carregar Horta" << endl;
			carregarHorta("hortas.txt", "armazem.txt", "registo.txt", h, a, areas);
			break;
		case '5':
			cout << "Escolheu a op��o Imprimir Horta" << endl;
            imprimeProdutos(h, a);
			break;
		case '6':
			cout << "Escolheu a op��o Criar nova �rea" << endl;
			novaArea(areas);
			break;
		case '7':
			cout << "Escolheu a op��o Mostrar Registo de Colhidos" << endl;
			registoColhidos(h);
			break;
		case'8':
			cout << "Escolheu a op��o alterar area" << endl;
			alteraArea(h,a);
			break;
		case '0':
			cout << "Escolheu a op��o voltar" << endl;
			sair = true;
			break;
		default:
			cout << "Escolha uma op��o v�lida." << endl;
		}
	} while (!sair);
}

//******************************* Op��o Gestor *******************************

//************************** 1 **************************

void removerProduto(armazem& a,horta& h) {
	string prod;
	cout << "Escreva o nome do produto a ser colhido: " << endl;
	cin.get();
	getline(cin, prod);
	prod = prod + " ";
	cout << endl;
	horta::hortas* iterator = h.inicio;
	while (iterator != 0) {
		produto* iteratorP = iterator->produtos;
		bool segundoP = false;
		while (iteratorP != 0 && segundoP == false) {
			if (iteratorP->nomeProduto == prod) {
				if (iteratorP->seguinte == 0) {
					iteratorP = NULL;
					iterator->produtos = iteratorP;
					iterator->ocupacao--;
				}
				else {
					produto* temp = iteratorP;
					iteratorP = temp->seguinte;
					temp->seguinte = NULL;
					iterator->produtos = iteratorP;
					iterator->ocupacao--;
				}
			}
			else {
				segundoP = true;
			}
		}
		iteratorP = iterator->produtos;
		while (segundoP == true && iteratorP->seguinte != 0) {
			if (iteratorP->seguinte->nomeProduto == prod) {
				if (iteratorP->seguinte->seguinte == 0) {
					iteratorP->seguinte = NULL;
					iterator->ocupacao--;
				}
				else {
					produto* temp = iteratorP->seguinte;
					iteratorP->seguinte = temp->seguinte;
					temp->seguinte = NULL;
					iterator->ocupacao--;
				}
			}
			if (iteratorP->seguinte != 0) {
				iteratorP = iteratorP->seguinte;
			}
			else {
				segundoP = false;
			}
		}
		iterator = iterator->seguinte;
	}

	cout << endl << endl;
	imprimeHortas(h);
	imprimeArmazem(a);
	cout << endl << "produto " << prod << " colhido!!" << endl << endl;
}
//************************** 2 **************************

void atualizaRega(armazem& a, horta& h) {
	
	string prod;
	int novaRega;
	cout << "Escreva o nome do produto a alterar rega: " << endl;
	cin.get();
	getline(cin, prod);
	prod = prod + " ";
	cout << "Escreva a nova rega: " << endl;
	cin >> novaRega;
	produto*iteratorh=h.inicio->inicio;
	while (iteratorh != 0)
	{
		if (iteratorh->nomeProduto == prod) {
			iteratorh->rega = novaRega;
		}
		iteratorh = iteratorh->seguinte;
	}
	

	produto* iteratorA = a.inicio;
	while (iteratorA != 0) {
		if (iteratorA->nomeProduto == prod) {
			iteratorA->rega = novaRega;
		}
		iteratorA = iteratorA->seguinte;
	}
	imprimeHortas(h);
	imprimeArmazem(a);
	cout << endl << "Foi atualizado a rega do produto " << prod << "." << endl << endl;
}
//************************** 3 **************************

void gravaHorta(string caminho_hortas, string caminho_armazem, string caminho_registo, horta& h, armazem& a) {
	horta::hortas* iterator = h.inicio;
	fstream fs;
	fs.open(caminho_hortas, ifstream::out);
	fs << h.nHortas << endl;

	while (iterator != 0) {
		
		fs << iterator->letra << endl;
		
		fs << iterator->responsavel << endl;
		
		fs << iterator->capacidade << endl;
		
		fs << iterator->ocupacao << endl;
		
		fs << iterator->area << endl;
		
		fs << iterator->produtosColhidos << endl;
		produto* iteratorP = iterator->produtos;
		while (iteratorP != 0) {
			
			fs << iteratorP->area << endl;
			
			fs << iteratorP->fornecedor << endl;
			
			fs << iteratorP->nomeProduto << endl;
			
			fs << iteratorP->rega << endl;
			iteratorP = iteratorP->seguinte;
		}
		iterator = iterator->seguinte;
	}

	fs.close();

	produto* iteratorA = a.inicio;
	fstream fa;
	fa.open(caminho_armazem, ifstream::out);
	fa << a.quantidade << endl;
	while (iteratorA != 0) {
		
		fa << iteratorA->area << endl;
		
		fa << iteratorA->fornecedor << endl;
		
		fa << iteratorA->nomeProduto << endl;
		
		fa << iteratorA->rega << endl;
		iteratorA = iteratorA->seguinte;
	}
	fa.close();

	string* registo = new string[500];
	fstream fr;
	fr.open(caminho_registo, ifstream::out);
	iterator = h.inicio;
	while (iterator != 0) {
		int i = 0;
		colhido* iteratorV = iterator->colhidos;
		travessiaPrefixa(iteratorV, registo, i);
		iterator = iterator->seguinte;
		for (int j = 0; j < i; j++) {
			fr << registo[j] << endl;
		}
	}
	fr.close();

	cout << endl << "horta gravada com sucesso!!" << endl;
}
void travessiaPrefixa(colhido* no, string registo[500], int& i) {
	if (no == NULL) {
		return;
	}
	registo[i] = no->nome;
	i++;
	registo[i] = to_string(no->rega);
	i++;
	cout << "produto: " << no->nome << " || pre�o: " << no->rega << endl;
	travessiaPrefixa(no->esq, registo, i);
	travessiaPrefixa(no->dir, registo, i);
}

//************************** 4 **************************

void carregarHorta(string caminho_Hortas, string caminho_armazem, string caminho_registo, horta& h, armazem& a, RArea* areas) {
	fstream fs;
	fs.open(caminho_Hortas, ios::in);
	string linha;
	string hortas[500];
	int tamanho = LinhasFicheiro(caminho_Hortas);
	for (int i = 0; i < tamanho; i++) {
		getline(fs, linha);
		hortas[i] = linha;
	}
	int tamhortas;
	stringstream t(hortas[0]);
	t >> tamhortas;
	h.nHortas = tamhortas;
	cout << "hortas: " << tamhortas << endl;
	areas->tam = 0;
	int pos = 1;

	h.inicio = NULL;
	for (int i = 0; i < tamhortas; i++) {
		horta::hortas* novo = new horta::hortas();
		char c_string = hortas[pos].at(0); // convers�o para tipo char
		//cout << "letras das hortas: ";
		novo->letra = c_string;
		pos++;
		//cout << "Responsavel pela horta: ";
		novo->responsavel = hortas[pos];
		pos++;
		//cout << "capacidade da horta: ";
		stringstream cap(hortas[pos]); // convers�o para tipo inteiro
		cap >> novo->capacidade;
		pos++;
		//cout << "Espa�o utilizado pelos produtos nas horta: ";
		stringstream ocp(hortas[pos]); // convers�o para tipo inteiro
		ocp >> novo->ocupacao;
		pos++;
		//cout << "�rea de cada horta: ";
		novo->area = hortas[pos];
		areas->area[areas->tam] = hortas[pos];
		areas->tam++;
		pos++;
		//cout << "Lista de produtos colhidos: ";
		stringstream prodColh(hortas[pos]); // convers�o para tipo inteiro
		prodColh >> novo->produtosColhidos;
		pos++;
		novo->produtos = NULL;
		for (int i = 0; i < novo->ocupacao; i++) {
			//cout << "�rea do Produto: ";
			produto* iteratorP = new produto();
			iteratorP->area = hortas[pos];
			pos++;
			//cout << "Fornecedor do Produto: ";
			iteratorP->fornecedor = hortas[pos];
			pos++;
			//cout << "Nome do Produto: ";
			iteratorP->nomeProduto = hortas[pos];
			pos++;
			//cout << "Tempo de Rega do Produto: ";
			stringstream rega(hortas[pos]); // convers�o para tipo inteiro
			rega >> iteratorP->rega;
			pos++;
			iteratorP->seguinte == NULL;
			if (novo->produtos == NULL) {
				novo->produtos = iteratorP;
			}
			else {
				produto* temp = novo->produtos;
				while (temp->seguinte != NULL) {
					temp = temp->seguinte;
				}
				temp->seguinte = iteratorP;
			}
		}
		novo->colhidos = NULL;
		novo->seguinte = NULL;
		if (h.inicio == NULL) {
			h.inicio = novo;
		}
		else {
			horta::hortas* iterator = h.inicio;
			while (iterator->seguinte != 0) {
				iterator = iterator->seguinte;
			}
			iterator->seguinte = novo;
		}
	}


	fs.close();

	fstream fa;
	fa.open(caminho_armazem, ios::in);
	string armazem[500];
	int tamanhoA = LinhasFicheiro(caminho_armazem);
	for (int i = 0; i < tamanhoA; i++) {
		getline(fa, linha);
		armazem[i] = linha;
	}
	int tamArmazem;
	stringstream ca(armazem[0]);
	ca >> tamArmazem;
	pos = 1;
	a.quantidade = tamArmazem;
	a.inicio = NULL;
	for (int i = 0; i < a.quantidade; i++) {
		produto* novo = new produto();
		//cout << "�rea do Produto: ";
		novo->area = armazem[pos];
		pos++;
		//cout << "Fornecedor do Produto: ";
		novo->fornecedor = armazem[pos];
		pos++;
		//cout << "Nome do Produto: ";
		novo->nomeProduto = armazem[pos];
		pos++;
		//cout << "Tempo de Rega do Produto: ";
		stringstream rega(armazem[pos]); // convers�o para tipo inteiro
		rega >> novo->rega;
		pos++;
		if (a.inicio == NULL) {
			a.inicio = novo;
		}
		else {
			produto* iterator = a.inicio;
			while (iterator->seguinte != 0) {
				iterator = iterator->seguinte;
			}
			iterator->seguinte = novo;
		}
	}
	fa.close();


	fstream fr;
	fr.open(caminho_registo, ios::in);
	string registo[500];
	int tamanhoR = LinhasFicheiro(caminho_registo);
	for (int i = 0; i < tamanhoR; i++) {
		getline(fr, linha);
		registo[i] = linha;
	}
	pos = 0;

	horta::hortas* iterator = h.inicio;
	while (iterator != 0) {
		for (int i = 0; i < iterator->produtosColhidos; i++) {
			//cout << "Nome do Produto colhido: ";
			colhido* novo = new colhido();
			novo->nome = registo[pos];
			pos++;
			//cout << "Tempo de Rega do Produto Colhido: ";
			stringstream pColhidos(registo[pos]); // convers�o para tipo inteiro
			pColhidos >> novo->rega;
			pos++;
			novo->dir = NULL;
			novo->esq = NULL;
			colhido* iteratorV = iterator->colhidos;
			bool colocado = false;
			while (colocado == false) {
				if (iteratorV == 0) {
					iteratorV = novo;
					colocado = true;
					iterator->colhidos = iteratorV;
				}
				else if (iteratorV->rega < novo->rega) {
					if (iteratorV->dir == NULL) {
						iteratorV->dir = novo;
						colocado = true;
					}
					else {
						iteratorV = iteratorV->dir;
					}
				}
				else if (iteratorV->rega >= novo->rega) {
					if (iteratorV->esq == NULL) {
						iteratorV->esq = novo;
						colocado = true;
					}
					else {
						iteratorV = iteratorV->esq;
					}
				}
			}
		}		iterator = iterator->seguinte;
	}
	fr.close();

	imprimeHortas(h);
	imprimeArmazem(a);

	cout << endl << "horta carregado com sucesso!!" << endl;
}

//************************** 5 **************************

void imprimeProdutos(horta& h, armazem& a) {
	cout << "Produtos presentes na horta: " << endl;
	horta::hortas* iterator = h.inicio;
	while (iterator != 0) {
		produto* iteratorP = iterator->produtos;
		while (iteratorP != 0) {
			cout << iteratorP->nomeProduto << endl;
			iteratorP = iteratorP->seguinte;
		}
		iterator = iterator->seguinte;
	}
	produto* iteratorA = a.inicio;
	while (iteratorA != 0) {
		cout << iteratorA->nomeProduto << endl;
		iteratorA = iteratorA->seguinte;
	}
	cout << endl;

}
//************************** 6 **************************

void novaArea(RArea* areas) {
	string novaArea;
	cout << endl << "Escreva o nome da nova �rea que pretende criar: " << endl;
	cin.get();
	getline(cin, novaArea);
	areas->area[areas->tam] = novaArea;
	areas->tam++;
	cout << endl << "Nova �rea criada!!" << endl << endl;
}

//************************** 7 **************************

void registoColhidos(horta& h) {
	horta::hortas* iterator = h.inicio;
	string nome;
	cout << "Escreva o nome do respons�vel da horta para aceder ao seu registo dos produtos colhidos: " << endl;
	cin.get();
	getline(cin, nome);
	bool existe = false;
	while (iterator != 0) {
		if (iterator->responsavel == nome) {
			cout << "Na horta cujo repons�vel e " << nome << " foi colhido " << iterator->produtosColhidos << " produtos." << endl;
			colhido* iteratorV = iterator->colhidos;
			travessiaInfixa(iteratorV);
			existe = true;
		}
		iterator = iterator->seguinte;
	}
	if (existe == false) {
		cout << "N�o existe nenhum respons�vel de horta com o nome: " << nome << endl;
	}
	cout << endl;
}

void travessiaInfixa(colhido* no) {
	if (no == NULL) {
		return;
	}
	travessiaInfixa(no->esq);
	cout << "produto: " << no->nome << " || rega: " << no->rega << endl;
	travessiaInfixa(no->dir);
}

//****************************** 8 ****************************************

void alteraArea(horta& h, armazem& a) {
	string AREA;
	string nArea;
	cout << "Indique o nome da area que pretende alterar " << endl;
	cin.get();
	getline(cin, AREA);
	horta::hortas* iteratorAr = h.inicio;
	while (iteratorAr != 0) {
		if (iteratorAr->area == AREA) {
			cout << "Escreva o nome da nova area " << endl;
			cin.get();
			getline(cin, nArea);
			nArea = " " + nArea;
			iteratorAr->area = nArea;
		}
		iteratorAr = iteratorAr->seguinte;
	}
	imprimeHortas(h);
	imprimeArmazem(a);
}