#pragma once


#include <iostream>
#include <string>
#include <locale>
#include <stdlib.h>
#include < time.h >
#include <fstream>
#include <sstream>
#include "ficheiros.h"

using namespace std;

//******************** Cria��o das struct(s) ********************

struct produto {
	string nomeProduto;
	int rega;
	string area;
	string fornecedor;
	produto* seguinte;
};

struct colhido {
	string nome;
	int rega;
	colhido* esq;
	colhido* dir;
};

struct horta {
	int nHortas;
	struct hortas {
		char letra;
		string responsavel;
		int capacidade;
		int ocupacao;
		string area;
		produto* produtos;
		int produtosColhidos;
		colhido* colhidos;
		hortas* seguinte;
		produto* inicio;
	};
	hortas* inicio;
};

struct armazem {
	int quantidade;
	produto* inicio;
};

struct RArea {
	string area[30];
	int tam;
};

//******************** Fun��es dos Sectores ********************

void criaHorta(horta& h, char letra, string responsavel, int capacidade, string area, int nSectores);

void imprimeHortas(horta& h);

//******************** Fun��es do Armazem ********************

void insereProduto(int quantidade, string nome[100], int tamanho_N, string fornecedores[50], int tamanho_F, RArea* area, armazem& a);

void criaProduto(armazem& a, string nome, string fornecedor, string area, int preco);

void imprimeArmazem(armazem& a);

//******************** Fun��es Op��o "s" ********************

void insereProdutoHorta(produto* temp, horta& h);

void colheProdutos(horta& h);

void insereProdutoColhido(produto* temp, horta& h, horta::hortas* iterator);

void imprimeProdutoColhido(produto* temp, horta::hortas* iterator);

void atualiza(armazem& a, horta& h);

//******************** Fun��es do Gestor ********************

void menu(armazem& a, horta& s, RArea* areas);

void removerProduto(armazem& a, horta& h);

void atualizaRega(armazem& a, horta& h);

void gravaHorta(string caminho_hortas, string caminho_armazem, string caminho_registo, horta& h, armazem& a);

void travessiaPrefixa(colhido* no, string registo[500], int& i);

void carregarHorta(string caminho_hortas, string caminho_armazem, string caminho_registo, horta& h, armazem& a, RArea* areas);

void imprimeProdutos(horta& h, armazem& a);

void novaArea(RArea* areas);

void registoColhidos(horta& h);

void travessiaInfixa(colhido* no);

void alteraArea(horta& h, armazem& a);

#pragma once