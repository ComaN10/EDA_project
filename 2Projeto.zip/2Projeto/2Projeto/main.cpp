#include <iostream>
#include <locale>
#include <stdlib.h>
#include < time.h >
#include <string>
#include <fstream>
#include "ficheiros.h"
#include "funcoes.h"


using namespace std;


int main() {
	armazem a;
	a.inicio = NULL;
	a.quantidade = 0;
	RArea* RAreas = new RArea;
	RAreas->tam = 0;

	locale::global(locale(""));

	//******************** Leitura de Ficheiros ********************

		// leitura �reas (linha a linha)
	fstream vA;
	vA.open("areas.txt", ios::in);
	string area[10];
	string linha;
	int tamanho_A = LinhasFicheiro("areas.txt");
	for (int i = 0; i < tamanho_A; i++) {
		getline(vA, linha);
		area[i] = linha;
	}

	// leitura produtos (linha a linha)
	fstream vN;
	vN.open("produtos.txt", ios::in);
	string nome[100];
	string linhaNome;
	int tamanho_N = LinhasFicheiro("produtos.txt");

	for (int i = 0; i < tamanho_N; i++) {
		getline(vN, linhaNome);
		nome[i] = linhaNome;
	}

	//leitura fornecedores (linha a linha)
	fstream vF;
	vF.open("fornecedores.txt", ios::in);
	string fornecedores[20];
	string linhaFornecedores;
	int tamanho_F = LinhasFicheiro("fornecedores.txt");

	for (int i = 0; i < tamanho_F; i++) {
		getline(vF, linhaFornecedores);
		fornecedores[i] = linhaFornecedores;
	}

	//******************** Cria��o das Hortas ********************

	srand(time(nullptr));
	int nHortas = rand() % 5 + 8;
	char letra[] = { "ABCDEFGHIJKL" };

	horta h;
	h.inicio = NULL;

	for (int i = 0; i < nHortas; i++) {
		char lHorta = { letra[i] };
		string responsavel;
		int capacidade = rand() % 6 + 5;
		cout << "Introduza o respons�vel pelo Horta " << letra[i] << ":" << endl;
		getline(cin, responsavel);
		int A = rand() % tamanho_A + 0;
		criaHorta(h, lHorta, responsavel, capacidade, area[A], nHortas);
		RAreas->area[i] = area[A];
		RAreas->tam++;
	}
	
	imprimeHortas(h);

	//******************** Cria��o do Armazem ********************

	insereProduto(15, nome, tamanho_N, fornecedores, tamanho_F, RAreas, a);
	imprimeArmazem(a);

	//*************************** menu ***************************

	char opcao;
	bool sair = false;
	do
	{
		cout << "(s)-seguinte ******************** (g)-gest�o ******************** (0)-Sair" << endl;
		cout << "Escolha uma op��o:\n";
		cin >> opcao;
		cout << endl;
		switch (opcao) {
		case 's':
			colheProdutos(h);
			atualiza(a, h);
			insereProduto(10, nome, tamanho_N, fornecedores, tamanho_F, RAreas, a);
			imprimeArmazem(a);
			break;
		case 'g':
			cout << "***** Bem Vindo ao Gestor *****" << endl;
			menu(a, h, RAreas);
			break;
		case '0':
			cout << "Escolheu a op��o Sair. Adeus!" << endl;
			sair = true;
			break;
		default:
			cout << "Escolha uma op��o v�lida." << endl;
		}
	} while (!sair);


	cin.get();
	cin.ignore();


	return 0;
}